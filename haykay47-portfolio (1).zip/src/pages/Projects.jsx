import React from 'react'

const projects = [
  { id:1, title:'Roblox Game / Site', desc:'Community site for Roblox project', img:'/assets/project1.svg', link:'https://adeyemihaykay47.wixsite.com/roblox-game-1' },
  { id:2, title:'Personal Site', desc:'Personal site showcasing projects', img:'/assets/project2.svg', link:'https://adeyemihaykay47.wixsite.com/my-site-4' },
  { id:3, title:'AI Assistant (demo)', desc:'AI prototype (placeholder)', img:'/assets/project3.svg', link:'#' }
]

export default function Projects(){
  return (
    <main className="container">
      <h1>Projects</h1>
      <div className="grid">
        {projects.map(p=>(
          <a key={p.id} className="card" href={p.link} target="_blank" rel="noreferrer">
            <img src={p.img} alt={p.title} />
            <h3>{p.title}</h3>
            <p>{p.desc}</p>
          </a>
        ))}
      </div>
    </main>
  )
}
