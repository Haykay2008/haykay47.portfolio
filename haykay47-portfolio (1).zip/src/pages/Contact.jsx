import React, {useState} from 'react'
import emailjs from 'emailjs-com'

export default function Contact(){
  const [status, setStatus] = useState('')
  const FORMSPREE_ENDPOINT = 'https://formspree.io/f/your-id' // replace this

  function handleSubmit(e){
    e.preventDefault()
    const form = e.target
    const data = new FormData(form)
    fetch(FORMSPREE_ENDPOINT, {method:'POST', body: data})
      .then(res=>{
        if(res.ok){ setStatus('Message sent via Formspree (demo).') }
        else {
          emailjs.sendForm('YOUR_SERVICE_ID','YOUR_TEMPLATE_ID',form,'YOUR_USER_ID')
            .then(()=>setStatus('Message sent via EmailJS (demo).'),()=>setStatus('EmailJS failed.'))
        }
      })
      .catch(()=> setStatus('Failed to send — configure Formspree or EmailJS.'))
    form.reset()
  }

  return (
    <main className="container">
      <h1>Contact</h1>
      <div className="contact-grid">
        <form className="contact-form" onSubmit={handleSubmit}>
          <label>Name<input name="name" required /></label>
          <label>Email<input name="email" type="email" required /></label>
          <label>Message<textarea name="message" rows="6" required /></label>
          <div className="form-actions">
            <button className="btn" type="submit">Send message</button>
            <div className="status">{status}</div>
          </div>
          <p className="note">Tip: replace <code>FORMSPREE_ENDPOINT</code> with your Formspree endpoint or fill EmailJS IDs in the file to send real emails.</p>
        </form>

        <aside className="contact-info">
          <h3>Contact Info</h3>
          <p>Email: <a href="mailto:adeyemihaykay47@gmail.com">adeyemihaykay47@gmail.com</a></p>
          <p>Discord: <strong>haykay47</strong></p>
          <div className="social-row">
            <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub">GitHub</a>
            <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn">LinkedIn</a>
            <a href="#" aria-label="Discord">Discord</a>
          </div>
        </aside>
      </div>
    </main>
  )
}
