import React from 'react'
import { Link } from 'react-router-dom'
import TypedTitle from '../ui/TypedTitle'
import Socials from '../ui/Socials'

export default function Home(){
  return (
    <main className="container">
      <section className="hero">
        <div className="hero-left">
          <h1 className="hero-name">Adewale Sulaimon Akorede</h1>
          <TypedTitle words={['Full-Stack Web Developer','AI Software & App Developer','Creator of websites & tools']} />
          <p className="hero-bio">I build responsive websites, AI-powered software and mobile-friendly apps. I blend practicality with clean UI and fast performance.</p>
          <div className="hero-ctas">
            <a className="btn" href="/projects">View Projects</a>
            <a className="btn ghost" href="/services">My Services</a>
          </div>
          <Socials />
          <p style={{marginTop:12,color:'var(--muted)'}}>Discord: <strong>haykay47</strong></p>
        </div>
        <div className="hero-right">
          <div className="avatar-large" role="img" aria-label="Adewale avatar">
            <svg viewBox="0 0 100 100" className="avatar-svg" xmlns="http://www.w3.org/2000/svg">
              <defs><linearGradient id="g2" x1="0" x2="1"><stop offset="0" stopColor="#6d28d9"/><stop offset="1" stopColor="#ec4899"/></linearGradient></defs>
              <rect rx="18" width="100" height="100" fill="url(#g2)"/>
              <text x="50" y="58" textAnchor="middle" fontSize="40" fill="#fff" fontFamily="Arial, Helvetica, sans-serif">AS</text>
            </svg>
          </div>
        </div>
      </section>

      <section className="preview-projects">
        <h2>Featured Projects</h2>
        <div className="grid">
          <a className="card" href="https://adeyemihaykay47.wixsite.com/roblox-game-1" target="_blank" rel="noreferrer">
            <img src="/assets/project1.svg" alt="Project 1" />
            <h3>Roblox Game / Site</h3>
            <p>Interactive Roblox community site with game info and media.</p>
          </a>

          <a className="card" href="https://adeyemihaykay47.wixsite.com/my-site-4" target="_blank" rel="noreferrer">
            <img src="/assets/project2.svg" alt="Project 2" />
            <h3>Personal Site</h3>
            <p>Personal site with projects and contact links built on Wix.</p>
          </a>

          <Link to="/projects" className="card more">
            <div className="more-inner">See all projects →</div>
          </Link>
        </div>
      </section>
    </main>
  )
}
