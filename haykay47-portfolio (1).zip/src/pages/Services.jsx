import React from 'react'

const services = [
  {id:1,title:'Web Development',desc:'Responsive websites using React, HTML, CSS and modern tooling.'},
  {id:2,title:'AI Software',desc:'AI integrations, prototypes and backend services for smart features.'},
  {id:3,title:'App Development',desc:'Mobile-friendly web apps and progressive web apps (PWAs).'}
]

export default function Services(){
  return (
    <main className="container">
      <h1>Services</h1>
      <div className="services-grid">
        {services.map(s=>(
          <div key={s.id} className="service-card">
            <div className="service-icon">{s.title[0]}</div>
            <h3>{s.title}</h3>
            <p>{s.desc}</p>
          </div>
        ))}
      </div>
    </main>
  )
}
