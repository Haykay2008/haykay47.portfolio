import React from 'react'

export default function Socials(){
  return (
    <div className="socials">
      <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 .5C5.7.5.9 5.3.9 11.6c0 4.7 3 8.7 7.2 10.1.5.1.7-.2.7-.5v-1.8c-2.9.6-3.6-1.2-3.6-1.2-.5-1.2-1.3-1.5-1.3-1.5-1-.7.1-.7.1-.7 1.1.1 1.7 1.1 1.7 1.1 1 .1 1.6.7 1.9 1.1.6-1 .8-1.8.5-2.2-2.3-.3-4.7-1.2-4.7-5.3 0-1.2.4-2.1 1.1-2.9-.1-.3-.5-1.6.1-3.4 0 0 .9-.3 3 1.1.9-.3 1.9-.5 2.9-.5s2 .2 2.9.5c2.1-1.4 3-1.1 3-1.1.6 1.7.2 3.1.1 3.4.7.8 1.1 1.7 1.1 2.9 0 4.1-2.5 5-4.8 5.3.3.3.5.8.5 1.6v2.4c0 .3.2.7.7.5 4.2-1.4 7.2-5.4 7.2-10.1C23.1 5.3 18.3.5 12 .5z" fill="currentColor"/></svg>
      </a>
      <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4.98 3.5C4.98 4.88 3.9 6 2.5 6S0 4.88 0 3.5 1.08 1 2.5 1 4.98 2.12 4.98 3.5zM.5 8h4V23h-4zM9 8h3.8v2.1h.1c.5-.9 1.8-1.8 3.8-1.8 4 0 4.7 2.6 4.7 6v8.7h-4v-7.7c0-1.8 0-4.2-2.6-4.2-2.6 0-3 2-3 4v7.9H9z" fill="currentColor"/></svg>
      </a>
      <span style={{marginLeft:8,color:'var(--muted)'}}>Discord: <strong>haykay47</strong></span>
    </div>
  )
}
