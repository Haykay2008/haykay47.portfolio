import React, {useEffect, useState} from 'react'

export default function TypedTitle({words = [], speed=90}){
  const [index, setIndex] = useState(0)
  const [subIndex, setSubIndex] = useState(0)
  const [blink, setBlink] = useState(true)
  useEffect(()=>{
    if(index >= words.length) return
    if(subIndex === words[index].length){
      const timeout = setTimeout(()=> setIndex(i=> (i+1)%words.length), 1200)
      return ()=> clearTimeout(timeout)
    }
    const timeout = setTimeout(()=> setSubIndex(s=> s+1), speed)
    return ()=> clearTimeout(timeout)
  },[subIndex, index, words, speed])
  useEffect(()=>{
    const timer = setInterval(()=> setBlink(b => !b), 500)
    return ()=> clearInterval(timer)
  },[])
  return (
    <h2 className="typed">
      {words[index].substring(0, subIndex)}
      <span className="cursor" style={{opacity: blink?1:0}}>█</span>
    </h2>
  )
}
