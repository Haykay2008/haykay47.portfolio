import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Projects from './pages/Projects'
import Services from './pages/Services'
import Contact from './pages/Contact'
import Logo from './components/Logo'

export default function App(){
  return (
    <div className="site">
      <nav className="nav">
        <div className="nav-left">
          <Logo />
          <span className="brand">Haykay47</span>
        </div>
        <div className="nav-right">
          <Link to="/">Home</Link>
          <Link to="/projects">Projects</Link>
          <Link to="/services">Services</Link>
          <Link to="/contact">Contact</Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>

      <footer className="footer">
        <div>© {new Date().getFullYear()} Haykay47</div>
        <div>Built with React • Multi-page</div>
      </footer>
    </div>
  )
}
