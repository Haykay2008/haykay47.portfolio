import React from 'react'

export default function Logo(){
  return (
    <div className="logo-wrap" aria-hidden>
      <svg width="46" height="46" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="g" x1="0" x2="1" y1="0" y2="1">
            <stop offset="0" stopColor="#6d28d9"/>
            <stop offset="1" stopColor="#ec4899"/>
          </linearGradient>
        </defs>
        <rect rx="18" width="100" height="100" fill="url(#g)"/>
        <text x="50" y="58" textAnchor="middle" fontSize="48" fill="#fff" fontFamily="Arial, Helvetica, sans-serif">AS</text>
      </svg>
    </div>
  )
}
